// THIS FILE IS DEPRECATED AND NO LONGER USED.
//
// API key configuration has been moved to a standard .env.local file.
// Please see the updated instructions in README.md for setting up your
// Gemini API key.
//
// You can safely delete this file.
